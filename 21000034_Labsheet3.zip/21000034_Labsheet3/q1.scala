import scala.io.StdIn
object q1{
  def ReverseString(str:String):String=str.reverse

  def main(args: Array[String]): Unit = {
    print("Enter the string\n");

    val name=StdIn.readLine();
    print("Reversed String :" +ReverseString(name));
  }

}
